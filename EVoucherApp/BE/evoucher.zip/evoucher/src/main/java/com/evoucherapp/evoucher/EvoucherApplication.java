package com.evoucherapp.evoucher;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EvoucherApplication {

	public static void main(String[] args) {
		SpringApplication.run(EvoucherApplication.class, args);
	}

}
