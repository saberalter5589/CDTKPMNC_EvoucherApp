package com.evoucherapp.evoucher;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EvoucherApplicationTests {

	@Test
	void contextLoads() {
	}

}
